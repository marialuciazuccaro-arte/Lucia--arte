# Aggiornamento v70 – rotazione home su cellulare

Caricare la cartella `assets/js` nella radice del repository, sostituendo il file esistente:

`assets/js/latest-work-rotation.js`

Cosa cambia:
- su computer la rotazione continua a partire al passaggio del mouse;
- su cellulare la galleria degli “Ultimi lavori pubblicati” parte automaticamente quando la card entra nello schermo;
- la rotazione si ferma quando la card esce dallo schermo, per non consumare inutilmente risorse;
- il link della card resta utilizzabile: non serve toccare l’immagine per far partire la galleria.
