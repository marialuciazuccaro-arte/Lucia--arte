(function () {
  'use strict';

  const ROTATION_DELAY = 1500;
  const VISIBLE_RATIO = 0.52;
  const visuals = Array.from(document.querySelectorAll('[data-latest-slides]'));

  if (!visuals.length) return;

  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const mobileLike = window.matchMedia && window.matchMedia('(hover: none), (pointer: coarse), (max-width: 760px)').matches;
  const states = new Map();

  function parseSlides(value) {
    return String(value || '')
      .split('|')
      .map((item) => item.trim())
      .filter(Boolean);
  }

  function setCounter(state) {
    if (state.counter) {
      state.counter.textContent = (state.index + 1) + '/' + state.slides.length;
    }
  }

  function showSlide(state, nextIndex) {
    state.index = nextIndex;
    if (state.image && state.slides[state.index]) {
      state.image.src = state.slides[state.index];
    }
    setCounter(state);
  }

  function showNext(state) {
    const nextIndex = (state.index + 1) % state.slides.length;
    showSlide(state, nextIndex);
  }

  function startRotation(state, advanceImmediately) {
    if (reduceMotion || state.slides.length < 2 || state.timer) return;
    state.visual.classList.add('is-rotating');
    if (advanceImmediately) showNext(state);
    state.timer = window.setInterval(function () {
      showNext(state);
    }, ROTATION_DELAY);
  }

  function stopRotation(state, reset) {
    if (state.timer) {
      window.clearInterval(state.timer);
      state.timer = null;
    }
    state.visual.classList.remove('is-rotating');
    if (reset) showSlide(state, 0);
  }

  visuals.forEach(function (visual) {
    const slides = parseSlides(visual.dataset.latestSlides);
    const image = visual.querySelector('.latest-card__image') || visual.querySelector('img');
    const counter = visual.querySelector('.latest-card__counter');
    const hint = visual.querySelector('.latest-card__hint');

    if (!image || slides.length < 2) return;

    slides.slice(1).forEach(function (src) {
      const preload = new Image();
      preload.src = src;
    });

    const state = {
      visual: visual,
      image: image,
      counter: counter,
      slides: slides,
      index: Math.max(0, slides.indexOf(image.getAttribute('src'))),
      timer: null,
      visible: false
    };

    if (state.index === -1) state.index = 0;
    setCounter(state);
    states.set(visual, state);

    visual.addEventListener('mouseenter', function () {
      if (!mobileLike) startRotation(state, true);
    });

    visual.addEventListener('mouseleave', function () {
      if (!mobileLike) stopRotation(state, true);
    });

    visual.addEventListener('focusin', function () {
      if (!mobileLike) startRotation(state, true);
    });

    visual.addEventListener('focusout', function () {
      if (!mobileLike) stopRotation(state, true);
    });

    if (mobileLike && hint) {
      hint.textContent = 'La galleria scorre automaticamente';
    }
  });

  function visibleEnough(element) {
    const rect = element.getBoundingClientRect();
    const height = Math.max(1, rect.height);
    const visible = Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0);
    return visible / height >= VISIBLE_RATIO;
  }

  if (mobileLike && !reduceMotion) {
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          const state = states.get(entry.target);
          if (!state) return;
          if (entry.isIntersecting && entry.intersectionRatio >= VISIBLE_RATIO) {
            startRotation(state, false);
          } else {
            stopRotation(state, false);
          }
        });
      }, { threshold: [0, 0.25, VISIBLE_RATIO, 0.75, 1] });

      states.forEach(function (state) {
        observer.observe(state.visual);
      });
    } else {
      let ticking = false;
      const checkVisibility = function () {
        ticking = false;
        states.forEach(function (state) {
          if (visibleEnough(state.visual)) {
            startRotation(state, false);
          } else {
            stopRotation(state, false);
          }
        });
      };
      const requestCheck = function () {
        if (!ticking) {
          ticking = true;
          window.requestAnimationFrame(checkVisibility);
        }
      };
      window.addEventListener('scroll', requestCheck, { passive: true });
      window.addEventListener('resize', requestCheck);
      checkVisibility();
    }
  }

  window.addEventListener('pagehide', function () {
    states.forEach(function (state) {
      stopRotation(state, false);
    });
  });
})();
